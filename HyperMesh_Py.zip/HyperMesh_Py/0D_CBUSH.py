##Title: Create_ 0D_CBush Elements
##Application:HyperMesh v2024.1
##Author:Vinoth D
##contact:vinothd@altair.com

##import Modules and libraries
import hm
from hm import entities

##get Model
model=hm.Model()

##create a element Constructor
element_collection=hm.CollectionByInteractiveSelection(model,entities.Element)

##convert into a list
c_bush_list=list(element_collection)

##loop them  and make it as 0D
for i in c_bush_list:
    x=i.centerx
    y=i.centery
    z=i.centerz
    a=i.node1
    b=i.node2
    model.nodemodify(nodeentity=a,x=x,y=y,z=z)
    model.nodemodify(nodeentity=b,x=x,y=y,z=z)

##End of Script