      
import hm
from hm import entities as et
system=hm.Model()
allprop=hm.Collection(system,et.Property,populate=True)
system.deletemark(allprop)
allcomps=hm.Collection(system,et.Component)

for i in allcomps:
    icomp=hm.Collection(system,hm.FilterByEnumeration(et.Component,ids=[i.id]))
    y=list(icomp)
    iele=hm.Collection(system,hm.FilterByCollection(et.Element,et.Component),icomp)
    x=list(iele)
    cd=x[0].typename
    print(f'{i.name}>>{cd}>>{i.id}')

    if cd=='CQUAD4' or 'CTRIA3':
        iprop=et.Property(system,cardimage='PSHELL',name=str(y[0].name))
        imat=et.Material(system,cardimage='MAT1',name=str(y[0].name))
        imat.E=210000
        imat.Nu=0.3
        imat.Rho=7850e-09
        imat.A=2.1e-6
        iprop.materialid=imat
        y[0].propertyid=iprop
            
    elif cd=='CTETRA' or 'CHEXA':
        iprop=et.Property(system,cardimage='PSOLID',name=str(y[0].name))
        imat=et.Material(system,cardimage='MAT1',name=str(y[0].name))
        imat.E=71000
        imat.Nu=0.33
        imat.Rho=2780e-09
        imat.A=2.1e-6
        iprop.materialid=imat
        y[0].propertyid=iprop
        
    else:
            print(f'{y[0].name}comp has 1ds')
