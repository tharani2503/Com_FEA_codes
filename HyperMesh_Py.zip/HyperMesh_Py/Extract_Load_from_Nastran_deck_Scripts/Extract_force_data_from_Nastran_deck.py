
##Import Modules
import hm
from hm import entities as ent

##get model on screen
model=hm.Model()

## start importing deck file
model.start_batch_import(mode=2)

model.feinputwithdata2(import_reader="#nastran\\nastran", filename="C:/Users/vinothd/OneDrive - Altair Engineering, Inc/BENCHMARKING_Others/Mahindra_MRV/Force_extractor_Nastran_decks/Run1.bdf", overwrite_flag=0, reserved1=0, cleanup_tolerance=0, blanked_component=0, offset_flag=0, string_array=["Nastran ", "NastranMSC ", "CREATE_ONE_COMP_ACROSS_INCLUDES ", "ASSIGNPROP_BYHMCOMMENTS ", "CREATE_PART_HIERARCHY", "IMPORT_MATERIAL_METADATA", "ANSA ", "ENGINEERINGENTITIES ", "PATRAN ", "FEMAP ", "HM_READ_PCL_GRUPEE_COMMENTS ", "EXPAND_IDS_FOR_FORMULA_SETS ", "CONTACTSURF_DISPLAY_SKIP ", "LOADCOLS_DISPLAY_SKIP ", "SYSTCOLS_DISPLAY_SKIP ", "VECTORCOLS_DISPLAY_SKIP ", "\\[DRIVE_MAPPING= \\]"], scale_factor=1, name_comps_by_layer=0)

model.end_batch_import()

###Create force collection 
Force_Collection=hm.Collection(model,ent.LoadForce,populate=True)

###Convert into List
Force_list=list(Force_Collection)

###Get Node Id
Node_List=[]

for i in Force_list:
    Node_List.append(i.entityid)

##get Coordinate

for i in Node_List:
    print(f'x={i.x}___y={i.y}___z={i.z}')


