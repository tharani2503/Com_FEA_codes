
##Open fem file
Fem_file=open(r"C:\Users\vinothd\Downloads\temp_fem.fem")

##Initialize Lists
a=[]
b=[]
i=0

file=open("C:\\Users\\vinothd\\Downloads\\force_DAta_1.csv",'w')

##file.write('S.No,ID,DOF_arrested\n')

##for eachline in Fem_file:
##    if 'SPC' in eachline:
##        a=eachline.split()       
##        if(len(a)>4):
##            file.write("{},{},{},{},{},{}\n".format("","","",i,a[2],a[3]))
##
##file.close()

print("file written")

for line in Fem_file:
    if "FORCE" in line:
        b=line.split()
        i=i+1
        print(b)
        if len(b)>4:
            file.write("{},{},{}\n".format(i,b[2],b[4]))
            
file.close()

print("completed")
