##Author: Vinoth D
##Date: 13/1/2025
##Application:HyperMesh 2024.1
##Contact:vinothd@altair.com
##this is a Proprietary Resource of Altair


##Import Modules
import hm
from hm import entities as ent
model=hm.Model()


## delete existing features
# collection = hm.Collection(model,ent.Feature,populate=True)
# model.deletemark(collection=collection)                         ''' not working in 2024.1'''
## may be add a dialog box to open some file-- enter a file path
##read-hm_File
#model.readfile(filename=r"C:\Users\vinothd\OneDrive - Altair Engineering, Inc\optistruct\SubModelling\Apillar\A_pillar_Feature_check.hm",load_cad_geometry_as_graphics=0)

surface_collection=hm.Collection(model,ent.Surface,populate=True)
element_collection = hm.Collection(model, hm.FilterByEnumeration(ent.Element, ids=hm.hwUIntList([])))

##Feature_detection
model. (hole2d_detection=1, hole3d_detection=1, fillet_detection=1, flange2d_detection=1, logo_detection=1, surface_collection=surface_collection, element_collection=element_collection, hole2d_minradius=0, hole2d_maxradius=40, hole3d_stephole=1, hole3d_minradius=0, hole3d_maxradius=20, hole3d_maxdepth=0.7, fillet_minradius=0, fillet_maxradius=40, flange2d_maxwidth=20, logo_maxwidth=50, logo_maxheight=2, logo_concavityfactor=1)

##create Regions
##region=ent.Region(model,name="fillet")

##create a Features collection
Feature_Collection=hm.Collection(model,ent.Feature,populate=True)
All_Feature=list(Feature_Collection)

##Initialize Empty list for segeregating features
Feature_Fillet=[]
Feature_Holes_3D=[]
Feature_Holes_2D=[]
Feature_Flanges=[]
Feature_Logos=[]

### Segeregate feature by Config

for enty in All_Feature:
    if enty.config==5:
        Feature_Holes_3D.append(enty)
    elif enty.config==6:
        Feature_Fillet.append(enty)
    elif enty.config==4:
        Feature_Holes_2D.append(enty)
    elif enty.config==3:
        Feature_Flanges.append(enty)
    else:
        Feature_Logos.append(enty)


##Temp

print(f'No.of Features={len(Feature_Collection)}\nFillets={len(Feature_Fillet)}\nHoles_2D={len(Feature_Holes_2D)}\nHoles_3D={len(Feature_Holes_3D)}\nFlanges={len(Feature_Flanges)},\nLogos={len(Feature_Logos)}')
### Filter each features by their geometric attributes

## Initilize Empty list for each sub collection
##Fillets
Fillet_0_5=[]
Fillet_5_10=[]
Fillet_10_15=[]
Fillet_15_20=[]
Fillet_20_25=[]
Fillet_25_30=[]
Fillet_30_35=[]
Fillet_35=[]

##Holes_3D
Holes_3D_0_5=[]
Holes_3D_5_10=[]
Holes_3D_10_15=[]
Holes_3D_15_20=[]
Holes_3D_20_25=[]
Holes_3D_25_30=[]
Holes_3D_30_35=[]
Holes_3D_35=[]

##Holes_2D
##Circular
Circular_Holes_2D_0_5=[]
Circular_Holes_2D_5_10=[]
Circular_Holes_2D_10_15=[]
Circular_Holes_2D_15_20=[]
Circular_Holes_2D_20_25=[]
Circular_Holes_2D_25_30=[]
Circular_Holes_2D_30_35=[]
Circular_Holes_2D_35=[]

##Rounded
Rounded_Holes_2D_0_5=[]
Rounded_Holes_2D_5_10=[]
Rounded_Holes_2D_10_15=[]
Rounded_Holes_2D_15_20=[]
Rounded_Holes_2D_20_25=[]
Rounded_Holes_2D_25_30=[]
Rounded_Holes_2D_30_35=[]
Rounded_Holes_2D_35=[]

##Square
Square_Holes_2D_0_5=[]
Square_Holes_2D_5_10=[]
Square_Holes_2D_10_15=[]
Square_Holes_2D_15_20=[]
Square_Holes_2D_20_25=[]
Square_Holes_2D_25_30=[]
Square_Holes_2D_30_35=[]
Square_Holes_2D_35=[]

##Rectangle
Rectangle_Holes_2D_0_5=[]
Rectangle_Holes_2D_5_10=[]
Rectangle_Holes_2D_10_15=[]
Rectangle_Holes_2D_15_20=[]
Rectangle_Holes_2D_20_25=[]
Rectangle_Holes_2D_25_30=[]
Rectangle_Holes_2D_30_35=[]
Rectangle_Holes_2D_35=[]

##Filtring Fillets
for enty in Feature_Fillet:

    if enty.feature_maxwidth>0 and enty.feature_maxwidth<=5:
        Fillet_0_5.append(enty)

    elif enty.feature_maxwidth>5 and  enty.feature_maxwidth<=10:
        Fillet_5_10.append(enty)

    elif enty.feature_maxwidth>10 and  enty.feature_maxwidth<=15:
        Fillet_10_15.append(enty)

    elif enty.feature_maxwidth>15 and enty.feature_maxwidth<=20:
        Fillet_15_20.append(enty)

    elif enty.feature_maxwidth>20 and  enty.feature_maxwidth<25:
        Fillet_20_25.append(enty)

    elif enty.feature_maxwidth>25 and  enty.feature_maxwidth<=30:
        Fillet_25_30.append(enty)

    elif enty.feature_maxwidth>30 and  enty.feature_maxwidth<=35:
        Fillet_30_35.append(enty)

    else:
        Fillet_35.append(enty)



##print fillets

print(Fillet_0_5)
print(Fillet_5_10)

##Filtering Holes_3D
for enty in Feature_Holes_3D:

    if enty.solidhole_topradmax>0 and enty.solidhole_topradmax<=5:
        Holes_3D_0_5.append(enty)

    elif enty.solidhole_topradmax>5 and enty.solidhole_topradmax<=10:
        Holes_3D_5_10.append(enty)

    elif enty.solidhole_topradmax>10 and enty.solidhole_topradmax<=15:
        Holes_3D_10_15.append(enty)

    elif enty.solidhole_topradmax>15 and enty.solidhole_topradmax<=20:
        Holes_3D_15_20.append(enty)

    elif enty.solidhole_topradmax>0 and enty.solidhole_topradmax<=5:
        Holes_3D_20_25.append(enty)

    elif enty.solidhole_topradmax>0 and enty.solidhole_topradmax<=5:
        Holes_3D_25_30.append(enty)

    elif enty.solidhole_topradmax>0 and enty.solidhole_topradmax<=5:
        Holes_3D_30_35.append(enty)

    else:
        Holes_3D_35.append(enty)

##Print 3d holes

print(Holes_3D_0_5)
print(Holes_3D_10_15)
##Segregating Holes_2D
##Initialize_Hole_2D_Lists
Rounded_Holes_2D=[]
Circular_Holes_2D=[]
Rectangle_Holes_2D=[]
Square_Holes_2D=[]

for i in Feature_Holes_2D:
    if i.feature_shape==4:
        Rounded_Holes_2D.append(i)

    elif i.feature_shape==2:
        Circular_Holes_2D.append(i)

    elif i.feature_shape==16:
        Rectangle_Holes_2D.append(i)

    else:
        Square_Holes_2D.append(i)

##Circular_Hole2D>>> feature_Shape=2
for enty in Circular_Holes_2D:

    if enty.hole_size1>0 and enty.hole_size1<=5:
        Circular_Holes_2D_0_5.append(enty)

    elif enty.hole_size1>5 and enty.hole_size1<=10:
        Circular_Holes_2D_5_10.append(enty)

    elif enty.hole_size1>10 and enty.hole_size1<=15:
        Circular_Holes_2D_10_15.append(enty)

    elif enty.hole_size1>15 and enty.hole_size1<=20:
        Circular_Holes_2D_15_20.append(enty)

    elif enty.hole_size1>20 and enty.hole_size1<=25:
        Circular_Holes_2D_20_25.append(enty)

    elif enty.hole_size1>25 and enty.hole_size1<=30:
        Circular_Holes_2D_25_30.append(enty)

    elif enty.hole_size1>30 and enty.hole_size1<=35:
        Circular_Holes_2D_30_35.append(enty)

    else:
        Circular_Holes_2D_35.append(enty)

##Rectangular_Hole2D>>> feature_Shape=16
for enty in Rectangle_Holes_2D:

    if enty.hole_size1>0 and enty.hole_size1<=5:
        Rectangle_Holes_2D_0_5.append(enty)

    elif enty.hole_size1>5 and enty.hole_size1<=10:
        Rectangle_Holes_2D_5_10.append(enty)

    elif enty.hole_size1>10 and enty.hole_size1<=15:
        Rectangle_Holes_2D_10_15.append(enty)

    elif enty.hole_size1>15 and enty.hole_size1<=20:
        Rectangle_Holes_2D_15_20.append(enty)

    elif enty.hole_size1>20 and enty.hole_size1<=25:
        Rectangle_Holes_2D_20_25.append(enty)

    elif enty.hole_size1>25 and enty.hole_size1<=30:
        Rectangle_Holes_2D_25_30.append(enty)

    elif enty.hole_size1>30 and enty.hole_size1<=35:
        Rectangle_Holes_2D_30_35.append(enty)

    else:
        Rectangle_Holes_2D_35.append(enty)

##Square_Holes2D>>> feature_Shape=8
for enty in Square_Holes_2D:

    if enty.hole_size1>0 and enty.hole_size1<=5:
        Square_Holes_2D_0_5.append(enty)

    elif enty.hole_size1>5 and enty.hole_size1<=10:
        Square_Holes_2D_5_10.append(enty)

    elif enty.hole_size1>10 and enty.hole_size1<=15:
        Square_Holes_2D_10_15.append(enty)

    elif enty.hole_size1>15 and enty.hole_size1<=20:
        Square_Holes_2D_15_20.append(enty)

    elif enty.hole_size1>20 and enty.hole_size1<=25:
        Square_Holes_2D_20_25.append(enty)

    elif enty.hole_size1>25 and enty.hole_size1<=30:
        Square_Holes_2D_25_30.append(enty)

    elif enty.hole_size1>30 and enty.hole_size1<=35:
        Square_Holes_2D_30_35.append(enty)

    else:
        Square_Holes_2D_35.append(enty)

##Rounded_Holes2D(Slots)>>> feature_Shape=4
for enty in Rounded_Holes_2D:

    if enty.hole_size1>0 and enty.hole_size1<=5:
        Rounded_Holes_2D_0_5.append(enty)

    elif enty.hole_size1>5 and enty.hole_size1<=10:
        Rounded_Holes_2D_5_10.append(enty)

    elif enty.hole_size1>10 and enty.hole_size1<=15:
        Rounded_Holes_2D_10_15.append(enty)

    elif enty.hole_size1>15 and enty.hole_size1<=20:
        Rounded_Holes_2D_15_20.append(enty)

    elif enty.hole_size1>20 and enty.hole_size1<=25:
        Rounded_Holes_2D_20_25.append(enty)

    elif enty.hole_size1>25 and enty.hole_size1<=30:
        Rounded_Holes_2D_25_30.append(enty)

    elif enty.hole_size1>30 and enty.hole_size1<=35:
        Rounded_Holes_2D_30_35.append(enty)

    else:
        Rounded_Holes_2D_35.append(enty)


##workspace
def surface_id_collector(feature_list):
    A=[]
    B=[]
    for i in feature_list:
        A.append(i)

    for i in A:
        B.append(i.id)
    
    Geometry_surface_Collection=hm.Collection(model,ent.Surface,B)
    return Geometry_surface_Collection

## get the id's for geometric entities using nested loop
def line_id_collector(feature_list):
    C=[]
    D=[]
    for i in feature_list:
        C.append(i.id)
    for i in C:
        D.append(i.id)

    Geometry_line_collection=hm.Collection(model,ent.Line,D)
    return Geometry_line_collection



## create regions



###pass them to Mesh Control 