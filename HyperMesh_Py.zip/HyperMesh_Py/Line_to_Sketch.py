##Title:Convert line to Sketch
##Application: HyperMesh v2025
##Date:17/3/2025
##Contact:vinothd@altair.com

## Import libraries
import hm
from hm import entities as enty

##get Model on Screen
model=hm.Model()

### Select midlines
midlines=hm.Collection(model,enty.Line,populate=True)
Line_collection=list(hm.Collection(model,enty.Line,populate=True))
a=len(Line_collection)

## create Temp nodes for defining plane normal and AXIS to define Projection plane
temp_linelist=Line_collection[:a:2] ### defining things in this way might not work for all cases IDEA: Define a if case base on the number of lines

for line in temp_linelist:
    model.nodecreateatlineparams(line_entity=line, double_array=[0, 1], insert_count=1, mode=1, point_flag=0)

Node_Collection=list(hm.Collection(model,enty.Node,populate=True))
b=len(Node_Collection)
Temp_Nodes=Node_Collection[:b:3]

##Calulate and define Plane Noramal and Axis
X_Coord=[]
Y_Coord=[]
Z_Coord=[]

for node in Temp_Nodes:
    X_Coord.append(node.x)
    Y_Coord.append(node.y)
    Z_Coord.append(node.z)

def Vectors(X_,Y_,Z_):
    global vector_a,vector_b
    ''' given three coplanar points it spits out two vectors '''
    vector_a=[X_[2]-X_[0],Y_[2]-Y_[0],Z_[2]-Z_[0]]
    vector_b=[X_[1]-X_[0],Y_[1]-Y_[0],Z_[1]-Z_[0]]
    return vector_a,vector_b

def Plane_Normal(A,B):
    '''given two vectors it spits out crossproduct'''
    Norm=[A[1]*B[2]-B[1]*A[2],A[2]*B[0]-B[2]*A[0],A[0]*B[1]-B[0]*A[1]]
    Normal=[i/((Norm[0]**2+Norm[1]**2+Norm[2]**2)**0.5) for i in Norm]
    print(Normal)
    return Normal

## Calling the Functions
Axis=Vectors(X_Coord,Y_Coord,Z_Coord)
Normalized_plane_drxn=Plane_Normal(A=vector_a,B=vector_b)
Plane_x_drxn=[i/((vector_a[0]**2+vector_a[1]**2+vector_a[2]**2)**0.5) for i in vector_a]

##Clear Temp Nodes
model.nodemarkcleartempmark(collection=hm.Collection(model,enty.Node,populate=True))

### Project line into the plane
sketch = enty.Sketch(model, name="sketch1", planenormal=Normalized_plane_drxn, planeorigin=[X_Coord[0],Y_Coord[0],Z_Coord[0]], planexdir=Plane_x_drxn)
model.sketchproject(sketch_id=1, collection=midlines, create_entities=1) # create_entities=0 does not create into sketch lines
model.startsketcheredit(sketcherID=1)
model.sketchedit(id=1, operation="merge", operation_method="merge_all")
sketch.realize_mode = 2