#Title:Extract_node_data_from_SolverDeck
#Application:HyperMesh v2024.1
#Date:
#Author:Vinoth
#Contact:vinothd@altair.com

##Import Modules
import hm
from hm import entities as ent
import tkinter
from tkinter import ttk
import time


##Get model
model=hm.Model()

##Component Collection
Component_collection=list(hm.Collection(model,ent.Component,populate=True))

with open ("D:/nodes_info.csv",mode="a") as csvfile:

    for each_comp in Component_collection:
        print(f"{each_comp.name}")
        Node_list=each_comp.nodes
        for each_node in Node_list:
            csvfile.write (str(each_node.x)+","+str(each_node.y)+','+str(each_node.z)+"\n")

