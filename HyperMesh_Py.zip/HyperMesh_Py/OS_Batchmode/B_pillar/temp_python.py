import os
##a=os.path.abspath(__file__)
##print(a)
##b=os.path.dirname(__file__)
##print(b)
##training_directory = os.path.dirname(b)
##print(training_directory)

##path=r"C:\Users\vinothd\PHYSICS\B_Pillar\Shell\Shell\fem"
##dir_list=os.listdir(path)
##
##for each_solverdeck in dir_list:
##    print(each_solverdeck)
##import os
##path=r"C:\Users\vinothd\OneDrive - Altair Engineering, Inc\PYTHON\HyperMesh_Py\New folder\solver_input-20250407T150201Z-001\solver_input"
##dir_list=os.listdir(path)
##b=os.path.dirname(path)
##print(b)

import os
import shutil
from pathlib import Path

Input_directory=r"C:\Users\vinothd\Downloads\modal_analysis_Shell\Shell\fem"
output_directory=r"C:\Users\vinothd\Downloads\modal_analysis_Shell\Shell\Out_b_pillar"

file=r"C:\Users\vinothd\Downloads\Shell\Shell\fem\Bpillar_var6.fem"

import hm
from hm import entities as ent

model=hm.Model()
i=1
## import_solverdeck
model.start_batch_import(mode=2)
model.feinputwithdata2(import_reader="#optistruct\\optistruct", filename=file, overwrite_flag=0, reserved1=0, cleanup_tolerance=0, blanked_component=0, offset_flag=0, string_array=["OptiStruct ", " ", "CREATE_ONE_COMP_ACROSS_INCLUDES ", "ASSIGNPROP_BYHMCOMMENTS ", "CREATE_PART_HIERARCHY", "IMPORT_MATERIAL_METADATA", "ANSA ", "ENGINEERINGENTITIES ", "PATRAN ", "EXPAND_IDS_FOR_FORMULA_SETS ", "CONTACTSURF_DISPLAY_SKIP ", "LOADCOLS_DISPLAY_SKIP ", "SYSTCOLS_DISPLAY_SKIP ", "VECTORCOLS_DISPLAY_SKIP ", "\\[DRIVE_MAPPING= \\]"], scale_factor=1, name_comps_by_layer=0)
model.end_batch_import()


##Create a new Loadstep Modal(3)
Modal = ent.Loadstep(model, name="Modal_Analysis")
Modal.OS_TYPE = 3

OS_SPCID = ent.Loadcol(model, 1)
Modal.OS_SPCID = OS_SPCID

##Create EIGRL CARD
EIGRL = ent.Analysisparameter(model,name="EIGRL")
EIGRL.v1 = 0
EIGRL.nd = 15
Modal.OS_METHOD_STRUCTID = EIGRL

## Create a directory
a=os.path.basename(file)
print(a)
b=os.path.splitext(a)[0]
print(b)
new_solverdeck_location=os.path.join(output_directory,b)
print(new_solverdeck_location)
print("111")
os.makedirs(new_solverdeck_location,exist_ok=True)
new_filename=os.path.join(new_solverdeck_location,"Run.fem")
type(new_filename)
print(new_filename)

##Export Solverdeck
model.retainmarkselections(mode=0)
model.feoutputmergeincludefiles(code=0)
model.setsubmodeltype(type="HM_INCLUDEFILES")
model.setentitytypesupportedbyenggid(string_array=hm.hwStringList([]))
model.feoutputwithdata(export_template=r"C:\Program Files\Altair\2025.1.0.21-209486\hwdesktop\templates\feoutput\optistruct\optistruct", filename=new_filename, reserved1=0, reserved2=0, export_type=1, string_array=["HM_NODEELEMS_SET_COMPRESS_SKIP ", "EXPORT_DMIG_LONGFORMAT ", "HMENGINEERING_XML", "HMSUBSYSTEMCOMMENTS_XML", "HMMATCOMMENTS_XML", "HMBOMCOMMENTS_XML", "INCLUDE_RELATIVE_PATH ", "EXPORT_SOLVER_DECK_XML_1 "])

## OS Batch_file_location
OS_batchfile="C:/Program Files/Altair/2025/hwsolvers/scripts/optistruct.bat"
##

command = f'"{OS_batchfile}" "{new_filename}" -nt 6'
subprocess.run(command, shell=True, check=True)
print("done")
