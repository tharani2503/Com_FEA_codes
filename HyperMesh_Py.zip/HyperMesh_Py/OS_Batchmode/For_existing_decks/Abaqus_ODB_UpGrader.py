##TiTle: Abaqus ODB Upgrader
##Author: Vinoth D
## contact:vinothd@altair.com 

## Import Modules
import os
import time
import subprocess
import log



## Input and Output Directories 
Input_Directory=r"C:\Users\vinothd\Downloads\ODB_Upgrader" 
Output_Directory=r"C:\Users\vinothd\Downloads\ODB_Upgrader\Final_upgraded"

##ODB Upgarder Batchfile
abaqus_odb_upgrade=r"C:\Program Files\Altair\2025.1\hwdesktop\io\result_readers\bin\win64\abaqus_odb_upgrade.exe" 

for file in os.listdir(Input_Directory):
    if file.endswith(".odb"):
        
        Input_File_Path=os.path.join(Input_Directory,file)
        Final_Path=os.path.join(Output_Directory,file)
        
        ##Command
        command=[abaqus_odb_upgrade,Input_File_Path,Final_Path] ##abaqus_odb_upgrade <old file> [new file]
        subprocess.run(command,shell=True,check=True)
        
