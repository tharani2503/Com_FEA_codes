import pandas as pd
import csv

file=pd.read_csv(r"C:\Users\vinothd\Downloads\Dummy_series_Ford_Custom_inputs\data\customer_csv.csv")

file=file.set_index("nodeID")
for i in file.columns:
    print(i)
print(file)


























































