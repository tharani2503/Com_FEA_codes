import os
import time
import shutil
import subprocess

##define Directory Paths
Output_Directory=r"C:\Users\vinothd\Downloads\new_only_modal_files"
Input_Directory=r"C:\Users\vinothd\Downloads\Output_results"
Config_file=""
HVT_bat=r"C:\Program Files\Altair\2025.1\hwdesktop\io\result_readers\bin\win64\hvtrans.exe"
file_extension=".h3d"
##Command Construct line

for file in os.listdir(Input_Directory):
    if file.endswith(file_extension):
        input_file_path=os.path.join(Input_Directory,file)
        output_file_path=os.path.join(Output_Directory,file)

##command = [Physics_Ai_batch_file,"-physicsai","-predict_write", output_file,"-model", pai_psdml_model_path,"-input_file", input_file_Path,"--hooks-dir",Physics_AI_hooks_Directory]
        ### Command
        command=[]
        
        
        
