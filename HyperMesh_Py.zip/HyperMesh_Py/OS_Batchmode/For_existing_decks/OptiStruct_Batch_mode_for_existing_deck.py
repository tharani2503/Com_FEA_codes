##Title:OS_Batch_mode
##Application:HyperMesh v2025.0
##Author:Vinoth D
##Date: 27/05/2025
##contact:vinothd@altair.com

import os
import subprocess
import shutil
import time
##Specify input folder and output folder

Input_directory=r"C:\Users\vinothd\OneDrive - Altair Engineering, Inc\Thermal buckling_Projects\NAfems\Actual_files_WIP\Square"
Output_directory=r"C:\Users\vinothd\OneDrive - Altair Engineering, Inc\Thermal buckling_Projects\NAfems\Actual_files_WIP\Square"

##OptiStruct batchfile location
OS_batchfile="C:/Program Files/Altair/2025/hwsolvers/scripts/optistruct.bat"


for each_file in os.listdir(Input_directory):
    if each_file.endswith (".fem"):

        ## Create a new folder for each solverdeck
        file_path=os.path.join(Output_directory,each_file)
        folder_path=os.path.splitext(file_path)[0]
        os.makedirs(folder_path, exist_ok=True)

        # Copy the deck file to new location
        source_path = os.path.join(Input_directory, each_file)
        destination_path = os.path.join(folder_path, each_file)
        shutil.copy(source_path, destination_path)

        # Construct the command to run OptiStruct with -nt 6
        command = f'"{OS_batchfile}" "{destination_path}" -nt 6'

        try:
            subprocess.run(command, shell=True, check=True)
            print(f"Simulation completed for \n")
            time.sleep(10)
        except subprocess.CalledProcessError as e:
            print(f"Error running simulation for {e}\n")
    else:
        print("No .fem files present in the given location ==> "f'{Input_directory}')

        
##end of script
