import hm
from hm import entities as ent
model=hm.Model()
surf_colln_1=hm.CollectionByInteractiveSelection(model,ent.Surface)

line_colln_1=hm.CollectionByAttached(model,surf_colln_1)
