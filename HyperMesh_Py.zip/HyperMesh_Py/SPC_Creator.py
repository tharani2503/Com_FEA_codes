##Author: Vinoth D
##Date: 21/1/2025
##Application:HyperMesh 2024.1

import hm 
from hm import entities as ent
model=hm.Model()

Constraints=ent.Loadcol(model,name="SPC")

SPC_Nodes=hm.Collection(model,ent.Node,[])
model.loadcreateonentity(SPC_Nodes,type=1,config=3,comp1=0,comp2=0,comp3=0,comp4=0,comp5=0,comp6=0)
