##Title:Zero_length_RBE2_or_CBUSH_Elements
##Application:HyperMesh v2024.1 or v2025.0
##Author:Vinoth D
##Date: 5-3-2025
##contact:vinothd@altair.com

## import modules
import hm
from hm import entities as ent

##get Model
model=hm.Model()

##Collect Elements
element_collection=hm.CollectionByInteractiveSelection(model,ent.Element)
one_D_List=list(element_collection)

## loop the collection and move the nodes
for i in one_D_List:
    x=i.centerx
    y=i.centery
    z=i.centerz
    ind_node=i.node1
    dep_node=i.node2
    model.nodemodify(nodeentity=ind_node,x=x,y=y,z=z)
    model.nodemodify(nodeentity=dep_node,x=x,y=y,z=z)