def imptorep(filepath,param_file,criteria_file):
    import hm
    from hm import entities  as ent
    model=hm.Model()
    model.deletemodel()

    ## start import cad
    model.start_batch_import(mode=3)
    model.geomimport(translator_type="parasolid_parasolid", input_file_name=filepath, options=["AvoidDisjointShells=on", "BodyIDAsMetadata=off", "CleanupTol=-0.01", "ColorsAsMetadata=off", "CreationType=Parts", "DegSurfTol=0.0", "DensityAsMetadata=on", "DisplayRepresentation=off", "DoNotMergeEdges=off", "ExtractManifoldFromGeneralBody=on", "FacetEdgeTolerance=1e-04", "FacetSurfaceTolerance=1e-04", "FacetingLevel=Medium", "ImportBlanked=off", "ImportFreeCurves=on", "ImportFreePoints=on", "LegacyHierarchyAsMetadata=off", "MID=MaterialId", "MaterialName=Material", "MeshFlag=MeshFlag", "OriginalIdAsMetadata=on", "PID=PID", "PartName=PartName", "PartNumber=PartNumber", "Revision=Revision", "ScaleFactor=1.0", "SkipCreationOfSolid=off", "SplitComponents=Body", "SplitPeriodicFaces=on", "StitchingAcrossBodies=on", "TagsAsMetadata=on", "TargetUnits=MMKS", "(mm", "kg", "N", "s)", "ThicknessName=Thickness", "UID=UID", "UniqueIdAsMetadata=off", "UpdateSketchingUnits=on", "VariantCondition=VariantCondition", "VariantScope=VariantScope"])
    model.end_batch_import()
    print('CAD imported successfully')
    ## finish CAD import

    comp=hm.Collection(model,ent.Component,populate=True)
    #solid=hm.Collection(model,ent.Solid,comp)
    allsurf=hm.Collection(model,ent.Surface,comp)
    print(len(allsurf))
    status,result=model.hm_getcentroid(allsurf)
    a=list(result.centroidCoordinates)
    print(a)
    cog= ent.Node(model, coordinates=a)
    print(cog)
    org=ent.Node(model,1)
    model.scalemark(allsurf, scale_x=2000, scale_y=2000, scale_z=2000, origin=cog)  
    ### executing BatchMesh###

    model.batchmesh2(allsurf,param_file='dummy',criteria_file='dummy')

    ##create property and material, and assign it to componenet###
    prop1=ent.Property(model,cardimage='PSHELL',name='2d_Property')
    prop1.PSHELL_T=1
    mate1=ent.Material(model,cardimage='MAT1',name='steel')
    prop1.materialid=mate1
    list(comp)[0].propertyid=prop1
    
paramfile = "C:/Program Files/Altair/2024.1/hwdesktop/hm/batchmesh/crash_5mm.param"
criteriafile = "C:/Program Files/Altair/2024.1/hwdesktop/hm/batchmesh/crash_5mm.critreria"


imptorep()