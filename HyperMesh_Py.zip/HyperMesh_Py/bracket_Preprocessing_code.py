def imptorep(filepath):
    import hm
    from hm import entities  as ent
    model=hm.Model()
    model.deletemodel()

    ## start import cad
    model.start_batch_import(mode=3)
    model.geomimport(translator_type="parasolid_parasolid", input_file_name=filepath, options=["AvoidDisjointShells=on", "BodyIDAsMetadata=off", "CleanupTol=-0.01", "ColorsAsMetadata=off", "CreationType=Parts", "DegSurfTol=0.0", "DensityAsMetadata=on", "DisplayRepresentation=off", "DoNotMergeEdges=off", "ExtractManifoldFromGeneralBody=on", "FacetEdgeTolerance=1e-04", "FacetSurfaceTolerance=1e-04", "FacetingLevel=Medium", "ImportBlanked=off", "ImportFreeCurves=on", "ImportFreePoints=on", "LegacyHierarchyAsMetadata=off", "MID=MaterialId", "MaterialName=Material", "MeshFlag=MeshFlag", "OriginalIdAsMetadata=on", "PID=PID", "PartName=PartName", "PartNumber=PartNumber", "Revision=Revision", "ScaleFactor=1.0", "SkipCreationOfSolid=off", "SplitComponents=Body", "SplitPeriodicFaces=on", "StitchingAcrossBodies=on", "TagsAsMetadata=on", "TargetUnits=MMKS", "(mm", "kg", "N", "s)", "ThicknessName=Thickness", "UID=UID", "UniqueIdAsMetadata=off", "UpdateSketchingUnits=on", "VariantCondition=VariantCondition", "VariantScope=VariantScope"])    
    model.end_batch_import()
    print('CAD imported successfully')
    ## finish CAD import

    comp=hm.Collection(model,ent.Component,populate=True)
    #solid=hm.Collection(model,ent.Solid,comp)
    allsurf=hm.Collection(model,ent.Surface,comp)
    print(len(allsurf))
    status,result=model.hm_getcentroid(allsurf)
    a=list(result.centroidCoordinates)
    print(a)
    cog= ent.Node(model, coordinates=a)
    print(cog)
    model.scalemark(allsurf, scale_x=2000000, scale_y=2000000, scale_z=2000000, origin=cog)  
    ### executing BatchMesh###
    model.batchmesh2(allsurf,param_file='dummy',criteria_file='dummy')
    print('meshing_completed')
    ##create property and material, and assign it to componenet###
    prop1=ent.Property(model,cardimage='PSHELL',name='2d_Property')
    prop1.PSHELL_T=1
    mate1=ent.Material(model,cardimage='MAT1',name='steel')
    mate1.E=210000
    mate1.Nu=0.3
    mate1.Rho=7.850**-9
    prop1.materialid=mate1
    list(comp)[0].propertyid=prop1
    print('property was assigned, pick some nodes create SPC')

    ### create Boundary Condition
    #create SPC

    spc=ent.Loadcol(model,name='SPC')
    constraint=hm.Collection(model,ent.Loadcol)
    spcid=list(constraint)[0].id
    model.loadtype(config='3',type='1')
    spc_nodes=hm.CollectionByInteractiveSelection(model,ent.Node)
    model.loadcreateonentity(spc_nodes, config=3, type=1, comp1=0, comp2=0, comp3=0, comp4=0, comp5=0, comp6=0)
    print('spc created and pick few nodes for applyong force')

    #create forces
    force=ent.Loadcol(model,name='FORCE')
    load=hm.Collection(model,ent.Loadcol,[2])
    loadid=list(force)[0].id
    model.loadtype(config='1',type='1')
    force_nodes=hm.CollectionByInteractiveSelection(model,ent.Node)
    model.loadcreateonentity(force_nodes,config=1,type=1,comp1=0,comp2=0,comp3=5,comp4=0,comp5=0,comp6=5)
    ###create_pressure
    #print('pick some elements on which pressure should be applied')
    #loadcol = ent.Loadcol(model)
    #loadcol.name = 'Pressures'
    #model.loadtype(config='4', type='1')

    #collection = hm.CollectionByInteractiveSelection(model, ent.Element)
    #facenodes = hm.Collection(model, hm.FilterByEnumeration(ent.Node, ids=[]))
    #model.pressuresonentity_curve(collection=collection, facenodes=facenodes, x_comp=0, y_comp=0, z_comp=0, magnitude=25, breakangle=30, onface=1)

    ###Create_loadStep
    loadstep=ent.Loadstep(model,name='Deflection analysis')
    loadstep.OS_TYPE=1
    OS_SPCID=ent.Loadcol(model,spcid)
    OS_LOADID=ent.Loadcol(model,loadid)
    loadstep.OS_SPCID=OS_SPCID
    loadstep.OS_LOADID=OS_LOADID






imptorep(r"C:\Users\vinothd\Downloads\TEMP\Surface_bodies\bracket_clip.x_t")
