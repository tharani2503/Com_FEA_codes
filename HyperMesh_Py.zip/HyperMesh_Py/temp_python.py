import os
##a=os.path.abspath(__file__)
##print(a)
##b=os.path.dirname(__file__)
##print(b)
##training_directory = os.path.dirname(b)
##print(training_directory)

##path=r"C:\Users\vinothd\PHYSICS\B_Pillar\Shell\Shell\fem"
##dir_list=os.listdir(path)
##
##for each_solverdeck in dir_list:
##    print(each_solverdeck)
import os
path=r"C:\Users\vinothd\PHYSICS\B_Pillar\Shell\Shell\fem"
dir_list=os.listdir(path)
b=os.path.dirname(path)
print(b)

import hm
from hm import entities as ent
model=hm.Model()
model.start_batch_import(mode=2)
model.feinputwithdata2(import_reader="#optistruct\\optistruct", filename=r"C:\Users\vinothd\PHYSICS\B_Pillar\Shell\Shell\fem\Bpillar_var3.fem", overwrite_flag=0, reserved1=0, cleanup_tolerance=0, blanked_component=0, offset_flag=0, string_array=["OptiStruct ", " ", "CREATE_ONE_COMP_ACROSS_INCLUDES ", "ASSIGNPROP_BYHMCOMMENTS ", "CREATE_PART_HIERARCHY", "IMPORT_MATERIAL_METADATA", "ANSA ", "ENGINEERINGENTITIES ", "PATRAN ", "EXPAND_IDS_FOR_FORMULA_SETS ", "CONTACTSURF_DISPLAY_SKIP ", "LOADCOLS_DISPLAY_SKIP ", "SYSTCOLS_DISPLAY_SKIP ", "VECTORCOLS_DISPLAY_SKIP ", "\\[DRIVE_MAPPING= \\]"], scale_factor=1, name_comps_by_layer=0)
model.end_batch_import()


##Delete existing Loadsteps
LSTcollection = hm.Collection(model,ent.Loadstep,Populate=True)
model.deletemark(collection=LSTcollection)
#Create a new Loadstep Modal(3)
Modal = ent.Loadstep(model, name="Modal_Analysis")
Modal.OS_TYPE = 3

OS_SPCID = ent.Loadcol(model, 1)
Modal.OS_SPCID = OS_SPCID

##Create EIGRL CARD
EIGRL = ent.Analysisparameter(model,name="EIGRL")
EIGRL.v1 = 0
EIGRL.nd = 15
Modal.OS_METHOD_STRUCTID = EIGRL
