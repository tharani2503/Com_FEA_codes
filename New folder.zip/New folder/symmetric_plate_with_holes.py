import numpy 
import matplotlib.pyplot as plt
import math

L=100
W=50
T=5
R=10
LD=30
WD=20

##initilize 
Nodes=[]

##Generate nodes with in domain
for x in numpy.linspace(0,L,LD):
    y0=math.sqrt(abs((R**2)-(x**2)))
    if (x<R):
        for y in numpy.linspace(y0,W,WD):
            Nodes.append([x,y])
    else:
        for y in numpy.linspace(0,W,WD):
            Nodes.append([x,y])

##Convert nodes into array
Node=numpy.array(Nodes)

print(Node)
#display nodes
plt.plot(Node[:,0],Node[:,1],'.')
plt.show()


from scipy.spatial import Delaunay
tri=Delaunay(Node)

plt.triplot(Node[:,0],Node[:,1],tri.simplices)
plt.plot(Node[:,0],Node[:,1],".")
plt.show()

p=[]
r2=9.5

for i in numpy.linspace(0,r2,50):
    p.append([i,math.sqrt(abs(r2**2-i**2))])

p1=[]
r3=8
for i in numpy.linspace(0,r3,20):
   p1.append([i,math.sqrt(abs(r3**2-i**2))])

p.extend(p1)
print(p)
a=tuple(tri.find_simplex(p))
tri.find_simplex(p)

Mesh_Grid=numpy.delete(tri.simplices,a,0)

plt.triplot(Node[:,0],Node[:,1],Mesh_Grid)
plt.plot(Node[:,0],Node[:,1],".")
plt.show()

print(len(Node))
print(len(Mesh_Grid))

file=open("E:\\plate_mesh_cs.csv",'w')
file.write('{},{},{},{}\n'.format("ID","x","y","z"))
#write nodes
for i,eachnode in enumerate(Node):
    file.write("{},{},{},{}\n".format(i,eachnode[0],eachnode[1],0))
#write elements
for j,element in enumerate(Mesh_Grid):
    file.write("{},{},{},{}\n".format(j,element[0],element[1],element[2]))
    
file.close()

vertices=numpy.array(Nodes)
from stl import mesh
import numpy as np
plate=mesh.Mesh(np.zeros(Mesh_Grid.shape[0],dtype=mesh.Mesh.dtype))
for i,m in enumerate(Mesh_Grid):
    for j in range(3):
        plate.vectors[i][j]=vertices[m[j],:]
plate.save("E:\\plate_quater_mesh_123.stl")
