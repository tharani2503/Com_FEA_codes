##Title:Extract Force Coordinates
##Author:Vinoth D
##Application:HyperMeshv2024.1
##Date:7/2/2025
##email:vinothd@altair.com

#import Module
import hm
from hm import entities as ent

##get Model
model=hm.Model()

###Create force collection 
Force_Collection=hm.Collection(model,ent.LoadForce,populate=True)

###Convert into List
Force_list=list(Force_Collection)

###Get Node Id
Node_List=[]

for i in Force_list:
    Node_List.append(i.entityid)

##get Coordinate

for i in Node_List:
    print(f'x={i.x}___y={i.y}___z={i.z}')
    
