import os
import shutil

# Define source and destination directories
source_dir = "E:/New folder (5)"
destination_dir = "E:/New folder (4)"
file_extension = ".h3d"  # Specify the file format (e.g., .txt, .jpg, .pdf)

# Ensure the destination directory exists
os.makedirs(destination_dir, exist_ok=True)

# Iterate through files in the source directory
for file_name in os.listdir(source_dir):
    if file_name.endswith(file_extension):  # Check file format
        source_path = os.path.join(source_dir, file_name)
        destination_path = os.path.join(destination_dir, file_name)
        
        # Move the file
        shutil.move(source_path, destination_path)
        print(f"Moved: {file_name}")

print("File transfer complete!")
