Python 3.13.1 (tags/v3.13.1:0671451, Dec  3 2024, 19:06:28) [MSC v.1942 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import tkinter as tk
... from tkinter import ttk
... 
... # Create the main window
... root = tk.Tk()
... root.title("Progress Bar Example")
... 
... # Create a Progressbar widget
... progress = ttk.Progressbar(root, orient="horizontal", length=300, mode="determinate")
... progress.pack(pady=20)
... 
... # Function to update the progress bar
... def update_progress():
...     progress["value"] += 10  # Increment progress by 10
...     if progress["value"] >= 100:
...         progress["value"] = 0  # Reset progress after reaching 100
... 
... # Add a button to trigger progress
... button = tk.Button(root, text="Update Progress", command=update_progress)
... button.pack(pady=10)
... 
... # Run the application
