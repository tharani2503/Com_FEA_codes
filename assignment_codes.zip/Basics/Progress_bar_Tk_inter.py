import tkinter as tk
from tkinter import ttk
import time

# Create the main window
root = tk.Tk()
root.title("Task Progress Bar")

# Create a Progressbar widget
progress = ttk.Progressbar(root, orient="horizontal", length=300, mode="determinate")
progress.pack(pady=20)

# Function to simulate a task
def simulate_task():
    progress["value"] = 0
    for i in range(101):  # Simulate task progress from 0 to 100
        progress["value"] = i
        root.update_idletasks()  # Update the GUI
        time.sleep(0.05)  # Simulate task delay

# Add a button to start the task
button = tk.Button(root, text="Start Task", command=simulate_task)
button.pack(pady=10)

# Run the application
root.mainloop()
