def inch_to_cm(a):
    return a*2.54
def inch_to_mm(a):
    return a*25.4
def cm_to_inch(s):
    return a/2.54
