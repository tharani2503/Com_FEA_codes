def sec_to_hrs(a):
    return a/3600
def hrs_to_mins(a):
    return a*60
