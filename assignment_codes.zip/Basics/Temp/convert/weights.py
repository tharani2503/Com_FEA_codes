def kg_to_lbs(a):
    return a*2.2046

def lbs_to_kg(a):
    return a/2.2046
