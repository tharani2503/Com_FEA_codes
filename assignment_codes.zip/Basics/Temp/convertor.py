##def converter(leng,mass):
import sys
import os
currentfilepath=__file__
print(currentfilepath)
print(type(currentfilepath))
cfdirectory=os.path.dirname(currentfilepath)
print(cfdirectory)
print(type(cfdirectory))
    
sys.path.append(cfdirectory)
import convert

a=convert.length.inch_to_cm(5)
print(f"the length is {a} cm")
b=convert.weights.kg_to_lbs(10)
print(f'the mass is {b} pounds')
