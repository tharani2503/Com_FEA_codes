import os
import shutil

def move_files_with_extension(source_dir, file_extension_1,file_extension_2, destination_dir):
    """
    Traverses through a directory and its subfolders, identifies files with the 
    specified extension, and moves them to the destination directory.

    Args:
        source_dir (str): The path to the directory to search in.
        file_extension (str): The file extension to look for (e.g., ".txt", ".pdf").
        destination_dir (str): The path to the directory where the files will be moved.
    """
    if not os.path.exists(destination_dir):
        os.makedirs(destination_dir)
    i=1
    for root, _, files in os.walk(source_dir):
        #print(files)
        i+=1
        for file in files:
            
            if file.lower().endswith(file_extension_1.lower()):
                name=(root.split("\\"))[-2]
                source_path = os.path.join(root, file)
                destination_path = os.path.join(destination_dir, name+str(file_extension_1.lower()))
                shutil.copy(source_path, destination_path)
                print(f"{i}Moved '{root}{file}' from '{root}' to '{destination_dir}'")
            if file.lower().endswith(file_extension_2.lower()):
                name=(root.split("\\"))[-2]
                source_path = os.path.join(root, file)
                destination_path = os.path.join(destination_dir, name+str(file_extension_2.lower()))
                shutil.copy(source_path, destination_path)
                print(f"{i}Moved '{root}{file}' from '{root}' to '{destination_dir}'")

                

# Example usage:
source_directory = r"C:\Users\vinothd\OneDrive - Altair Engineering, Inc\Thermal buckling_Projects\NAfems\Actual_files_WIP\Square"  # Replace with the actual source directory path
file_type_1= ".h3d"
file_type_2= ".fem" # Replace with the desired file extension
destination_directory = r"C:\Users\vinothd\OneDrive - Altair Engineering, Inc\Thermal buckling_Projects\NAfems\Actual_files_WIP\Square_data"  # Replace with the actual destination directory path

move_files_with_extension(source_directory, file_type_1,file_type_2,destination_directory)
