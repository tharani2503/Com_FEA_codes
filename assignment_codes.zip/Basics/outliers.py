mode1=[10,20,30,40,50,67,80,86,90,94]
mode2=[10,20,30,40,50,67,73,79,85]
mode3=[10,20,30,40,50,56,62,67,73,79,85]
mode4=[10,20,30,40,67,73,79,85]
mode5=[10,20,30,40]

print(set(mode1)&set(mode2))
print(set(mode1)&set(mode3))
print(set(mode1)&set(mode4))
print(set(mode1)&set(mode5))
