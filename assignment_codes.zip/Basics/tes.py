from pathlib import Path

# Specify the folder name
folder_name = r"C:\Users\vinothd\OneDrive - Altair Engineering, Inc\PYTHON\HyperMesh_Py\batchmode"

# Create the folder
Path(folder_name).mkdir(exist_ok=True)
print(f"Folder '{folder_name}' created successfully!")
