import numpy as np
import matplotlib.pyplot as plt
def func(*args):
    S=args[0]
    T=np.arange(0,S,0.01)
    theta=(180/(np.pi))*T
    R=T**2
        
    fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
    ax.plot(T,R)  # Plot your data
    
    plt.show()
##import matplotlib.pyplot as plt
##import numpy as np
##
## Generate some data for demonstration
##r = np.arange(0, 2, 0.01)  # Radial values
##theta = 2 * np.pi * r  # Angular values
##
## Create a polar plot
##fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
##ax.plot(theta, r)  # Plot your data
##
## Customize the plot (optional)
##ax.set_rmax(2)  # Set the maximum radial value
##ax.set_rticks([0.5, 1, 1.5, 2])  # Specify radial ticks
##ax.set_rlabel_position(-22.5)  # Adjust radial label position
##ax.grid(True)  # Show grid lines
##ax.set_title("A Line Plot in Polar Coordinates", va='bottom')  # Set a title
##
##plt.show()  # Display the plot
