##import urllib
##import webbrowser
##url = "https://www.geeksforgeeks.org"
##
##f = urllib.urlopen(url)
##file = f.read()
##f.close
##f2 = open('download.exe', 'w')
##f2.write(file)
##f2.close


##import os
####source_dir="E:/New folder (4)"
####
####for file_name in os.listdir(source_dir):
####    if file_name.endswith(".bdf"):
####        absolute_path = os.path.abspath(file_name)
####        print(absolute_path)


##a=r"C:/Program Files/Altair/2025/hwsolvers/scripts/optistruct.bat"
##b=r"C:/Users/vinothd/Downloads/116_102.fem"
##os.system(f"{a}{b}")

####import os
####
####file_path = "path/to/your/"
####a="file.txt"
####
####file_name_without_extension = os.path.splitext(os.path.join(file_path,a))[0]
####
####print(file_name_without_extension)
##import csv
##import numpy as np
##import matplotlib.pyplot as plt
##import array as ar
##
##time=[]
##force=[]
##
##with open ("C:/Users/vinothd/Downloads/Dummy_series/Book1.csv",'r') as file:
##    reader=csv.reader(file)
##    for row in reader:
##        time.append(row[0])
##        force.append(row[1])
##t=np.array(time[0:2000])
##f=np.array(force[0:2000])
##
##
##freq_data=np.fft.fft(f)
##
##N=len(freq_data)
##k=int(0.01*N)
##
##indices=np.argsort(np.abs(freq_data))[-k:]
##compressed_freq_data=np.zeros_like(freq_data,dtype=complex)
##compressed_freq_data[indices]=freq_data[indices]
##
##compressed_time_data=np.fft.ifft(compressed_freq_data).real
##print(compressed_time_data)
####plt.title("force vs time")
####plt.xlabel("time")
####plt.ylabel("force")
####plt.plot(t,f)
####plt.show()

import os
import shutil

file_extension=".json"
input_path="E:/B_pillar_data_set/Train"
output_path="E:/B_pillar_data_set"
for files in os.listdir(input_path):
    if files.endswith(file_extension):
        print(files)
        source_path=os.path.join(input_path,files)
        
        a=files.replace("_inp",'')
        print(a)
        destination_path=os.path.join(output_path,a)

        shutil.move(source_path,destination_path)
        
        
