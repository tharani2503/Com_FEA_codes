deltat=0.001
deltax=0.01
Time=100 ## simulation time
nt=int((Time)/(deltat)) ## no of timesteps
 ##totalsimulation time
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.animation as animation
##fig,ax=plt.subplots()


T=2              ##tension in the string
munot=1          ##lineardensity
c=(T/munot)**0.5 ###c^2 velocity   
beta=0.1      ##coefficient of damping
x=[float(i/100) for i in range(0,101)]
m1=1
m2=1/9
unow=[(m1*i) for i in x[0:11]]
u2=[(m2*(1-i))for i in x[11:101]]
unow.extend(u2)
uprevious=unow.copy()
unext=unow[:]

for t in range(0,nt):
   
    for ui in range(1,100):
        
##        u=(deltat**2)*(((T/munot)*(unow[ui+1]- 2*unow[ui] + unow[ui-1]))/deltax**2) - (((deltat)*(0.5*beta))*(unext[ui] - uprevious[ui]))+ (2*(unow[ui])-(uprevious[ui]))
        u=((2*(deltat**2))/(2+(beta*deltat)))*((((c**2)/(deltax**2))*(unow[ui+1] + unow[ui-1])) + ((2*unow[ui])*((1/(deltat**2))- ((c**2)/(deltax**2)))) +((uprevious[ui])*((beta/(2*deltat))-(1/(deltat**2)))))
        unext[ui]=u
##    print(unext)
        
    uprevious=unow.copy()
    unow=unext.copy()
    if t%50 == 0:
        plt.clf()
        plt.plot(x,unow)
        plt.axis((0,1, -0.15,0.15))
        plt.pause(0.001)

##plt.show()
    
##ani=animation.FuncAnimation(fig=fig, func=update,frames=1000,interval=10)
##plt.show()


     
        

