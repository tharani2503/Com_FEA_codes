import functools


def dec(fn):
    @functools.wraps(fn)
    def wrap(*args, **kwds):
        res = fn(*args, **kwds)
        return res
    return wrap





@dec
def average(*args):
    """find average of numbers"""
    return sum(args)/len(args)


