import math
##Initialize_lists
##function_1: cross product- get three points in and returns the resultant vector
def CrossProduct(a,b,c): ## function-1
    ##form two vectors from three points
    ab_vec=[b[0]-a[0],b[1]-a[1],b[2]-a[2]]
    bc_vec=[c[0]-b[0],c[1]-b[1],c[2]-b[2]]
    ##take cross products
    cross_product=[ab_vec[1]*bc_vec[2]-ab_vec[2]*bc_vec[1], ab_vec[2]*bc_vec[0]-ab_vec[0]*bc_vec[2], ab_vec[0]*bc_vec[1]-ab_vec[1]*bc_vec[0]]
    normalized_vector=[i/((cross_product[0]**2+cross_product[1]**2+cross_product[2]**2)**0.5) for i in cross_product]
    
    return normalized_vector

##function_2: find angle between given two vectors
def Angle_finder(a,b):## function-2
    ##dot product of vectors
    a_Dot_b=a[0]*b[0]+ a[1]*b[1]+ a[2]*b[2]
    ##modulus of vectors
    mod_a=math.sqrt(a[0]**2 +a[1]**2 +a[2]**2)
    mod_b=math.sqrt(b[0]**2 +b[1]**2 +b[2]**2)
    divider=mod_a*mod_b
    ##degree _conversion_factor
    deg=180/math.pi
    ##compute_angle
    theta = math.acos(a_Dot_b/divider)*deg
    return theta

def trigen(p1,p2,p3):
    print("trigen 1st time")
    while True:
        import random
        a=random.random()
        b=(1-a)*random.random()
        c=1-a-b
        yield(a*p1[0]+b*p2[0]+c*p3[0],
              a*p1[1]+b*p2[1]+c*p3[1],
              a*p1[2]+b*p2[2]+c*p3[2],)

    
def Quad_geneartor(p1,p2,p3,p4):
    points=[p1,p2,p3,p4]
    p2_vec=CrossProduct(p1,p2,p3)
    p3_vec=CrossProduct(p2,p3,p4)
    p4_vec=CrossProduct(p3,p4,p1)
    p1_vec=CrossProduct(p4,p1,p2)

    ang_1=Angle_finder(p2_vec,p1_vec)
    ang_2=Angle_finder(p2_vec,p2_vec)
    ang_3=Angle_finder(p2_vec,p3_vec)
    ang_4=Angle_finder(p2_vec,p4_vec)

    Angles=[ang_1,ang_2,ang_3,ang_4]
    print(Angles)
    d=Angles.index(180)
##    if d%2==0:
##        trigen(points[0],points[2],points[1])
##        trigen(points[0],points[2],points[3])
##    else:
##        trigen(points[1],points[3],points[0])
##        trigen(points[1],points[3],points[2])
        
    if (Angles.count(0)<Angles.count(180)):
    
        trigen(points[0],points[1],points[Angles.index(0)])
        trigen(points[2],points[3],points[Angles.index(0)])
    else:
        trigen(points[0],points[1],points[Angles.index(180)])
        trigen(points[2],points[3],points[Angles.index(180)])
        
    
    
