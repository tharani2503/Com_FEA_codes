from assignment_3_decorator import shopkeeper
def area(*args):
    p1,p2,p3=args    
    a=((p1[0]-p2[0])**2+(p1[1]-p2[1])**2+(p1[2]-p2[2])**2)**0.5
    b=((p3[0]-p2[0])**2+(p3[1]-p2[1])**2+(p3[2]-p2[2])**2)**0.5
    c=((p1[0]-p3[0])**2+(p1[1]-p3[1])**2+(p1[2]-p3[2])**2)**0.5
    s=(a+b+c)/2
    tria=(s*(s-a)*(s-b)*(s-c))**0.5
    return tria

def centroid(*args):
    p1,p2,p3=args
    x=(p1[0]+p2[0]+p3[0])/3
    y=(p1[1]+p2[1]+p3[1])/3
    z=(p1[2]+p2[2]+p3[2])/3
    return [x,y,z]
def mid(*args):
    p1,p2=args
    x=(p1[0]+p2[0])/2
    y=(p1[1]+p2[1])/2
    z=(p1[2]+p2[2])/2
    return [x,y,z]
@shopkeeper
def spliter(*args):
    areatolerence=10
    p1,p2,p3=args
    allareas=[]
    dummy1=list(args)
    dummy2=[]
    s=''
    while True:
         if len(dummy1):
             source=dummy1
             target=dummy2
             s='dummy1'
         else:
             source=dummy2
             target=dummy1
             s='dummy2'

         if len(source) == 0 and len(target) == 0:
             break

         while len(source):
             p1,p2,p3=source[:3]
             source=source[3:]
             if area(p1,p2,p3)>areatolerence:
##                 center=centroid(p1,p2,p3)
                 mid12=mid(p1,p2)
                 mid23=mid(p2,p3)
                 mid31=mid(p3,p1)

                 target.extend([p1,mid12,mid31,p2,mid12,mid23,mid12,mid31,mid23,p3,mid31,mid23])
             else:
                 allareas.extend([p1,p2,p3])

         if s=='dummy1':
             dummy1.clear()
         else:
             dummy2.clear()
    return allareas

######## processing stlfile #########
stlfile=open("C:/Users/vinothd/PYTHON/assignments/myTet.stl")
points=[]
areas=[]
centroids=[]
volume=[]
for eachline in stlfile:
    if 'normal' in eachline:
        a=eachline.split()
        b=a[2:]
        normal=[float(components) for components in b]
        n1,n2,n3=normal
        N=((n1**2)+(n2**2)+(n3**2))**0.5
        un=[nc/N for nc in normal] ## unit normal
    
    if 'vertex' in eachline:
      a=eachline.split()
      b=a[1:]               ## packing needed elements from a list
      c=[float(coordinates) for coordinates in b]
      points.append(c)
      if len(points)==3:
         p1,p2,p3=points ##unpacking
         alltria=spliter(p1,p2,p3)
##         print("processed")
##         print(alltria)

         for i in range(int(len(alltria)/3)):

             p1,p2,p3=alltria[:3]
             alltria=alltria[3:]
             a=((p1[0]-p2[0])**2+(p1[1]-p2[1])**2+(p1[2]-p2[2])**2)**0.5
             b=((p3[0]-p2[0])**2+(p3[1]-p2[1])**2+(p3[2]-p2[2])**2)**0.5
             c=((p1[0]-p3[0])**2+(p1[1]-p3[1])**2+(p1[2]-p3[2])**2)**0.5
             s=(a+b+c)/2
             area1=(s*(s-a)*(s-b)*(s-c))**0.5 ##calculating area
             areas.append(area1)
            
             xc=(p1[0]+p2[0]+p3[0])/3
             yc=(p1[1]+p2[1]+p3[1])/3
             zc=(p1[2]+p2[2]+p3[2])/3
                     
             fx = (xc/3)+(yc**1)*(zc**0)
             fy = (yc/3)+(zc**1)*(xc**0)
             fz = (zc/3)+(xc**1)*(yc**0)
             
             F=[fx,fy,fz]   ##defining the vector field

             v1=(F[0]*un[0]+F[1]*un[1]+F[2]*un[2])*area1 ## calculating volume
             volume.append(v1)
         points.clear() ## clearing the list so that the len becomes 0
         un.clear()
##print(areas)
print(sum(areas))
##print(v1)
print(sum(volume))
