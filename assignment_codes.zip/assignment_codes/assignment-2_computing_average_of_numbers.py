def fn(*args):
    if len(args)==0:
        print("wrong input, please give me some number")
    else:
        Avg=sum(args)/len(args)
        print("Average")
        print(Avg)
        
        

        
