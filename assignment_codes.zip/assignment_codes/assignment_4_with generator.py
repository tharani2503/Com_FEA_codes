##def fibo(a,b,c):
##    while a+b<c:
##        yield a+b
##        temp= a+b
##        a=b
##        b=temp
        
def ranger(*args):
    """If only one number is specified
       if two numbers
       if 3 numbers
    """
##single input(end)##
    if len(args)==1 and args[0]>0:
        start=0
        limit=args[0]
        while start<limit:
            yield start
            temp=start
            start=temp+1

##two input(start,end)##

    elif len(args)==2 and args[1]>args[0]:
        start,end=args
        while start<end:
            yield start
            temp=start+1
            start=temp
##three input(start,end,step)##
    elif len(args)==3:
        start,end,step=args

        if end>start and step>0:
            while(end - start)>0:
                yield start
                temp=start+step
                start=temp
        elif end<start and step<0:
            while (start-end)>0:
                yield start
                temp=start+step
                start=temp
##        else:
##            

listofpoints=ranger(-1,10,0.5)
for i in listofpoints:
    print(i)
    
            
            
            
