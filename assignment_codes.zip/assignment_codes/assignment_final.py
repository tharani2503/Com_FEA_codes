import mydecorator

#@mydecorator.timekeeper
#@mydecorator.logwriter
def openhmfile(filepath):
    import hm
    model = hm.Model()
    model=model.readfile(filepath,0)
    
