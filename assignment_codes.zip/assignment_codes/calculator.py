from hwx import gui

input=gui.LineEdit()
input.enabled=False

def onclick0():input.text=input.text+"0"
def onclick1():input.text=input.text+"1"
def onclick2():input.text=input.text+"2"
def onclick3():input.text=input.text+"3"
def onclick4():input.text=input.text+"4"
def onclick5():input.text=input.text+"5"
def onclick6():input.text=input.text+"6"
def onclick7():input.text=input.text+"7"
def onclick8():input.text=input.text+"8"
def onclick9():input.text=input.text+"9"
def onclick_add():input.text=input.text+"+"
def onclick_subtract():input.text=input.text+"-"
def onclick_multiply():input.text=input.text+"*"
def onclick_divide():input.text=input.text+"/"
def onclick_equals():input.text=eval(input.text)
def onclick_clear():input.text=""

gridframe=gui.GridFrame=(
(input),
(gui.PushButton("9",command=onclick9), gui.PushButton('8',command=onclick8),gui.PushButton("7",command=onclick7),gui.PushButton("x",command=onclick_multiply)),
(gui.PushButton("6",command=onclick6),gui.PushButton("5",command=onclick5),gui.PushButton("4",command=onclick4),gui.PushButton("/",command=onclick_divide)),
(gui.PushButton("3",command=onclick3),gui.PushButton("2",command=onclick2),gui.PushButton("1",command=onclick1),gui.PushButton("+",command=onclick_add)),
(gui.PushButton("-",command=onclick_subtract),gui.PushButton("0",command=onclick0),gui.PushButton("=",command=onclick_equals),gui.PushButton("C",command=onclick_clear)))

show(gridframe)