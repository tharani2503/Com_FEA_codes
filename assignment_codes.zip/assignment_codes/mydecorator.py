def timekeeper(fnp):
    def opener(*args,**kwds):
        import time
        start=time.time()
        i=fnp(*args,**kwds)
        end=time.time()
        print('importing time = ',end-start)
        return i
    return(opener)


def logwriter(fnp):
    def opener(*args,**kwds):
        print("import started")
        i=fnp(*args,**kwds)
        print("import finished")
        return i
    return opener


