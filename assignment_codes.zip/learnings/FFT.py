import numpy as np
import matplotlib.pyplot as plt

# Sample time-domain data (replace with your actual data)
sampling_rate = 1000  # Samples per second
duration = 1  # Duration in seconds
time = np.linspace(0, duration, sampling_rate * duration, endpoint=False)
signal = np.sin(2 * np.pi * 50 * time) + 0.5 * np.sin(2 * np.pi * 150 * time) # Example signal

# Perform FFT
fft_result = np.fft.fft(signal)

# Calculate the frequency axis
frequencies = np.fft.fftfreq(len(signal), 1/sampling_rate)

# Get the magnitude spectrum
magnitude_spectrum = np.abs(fft_result)

# Plotting
plt.figure(figsize=(10, 10))

# Time domain
plt.subplot(2, 1, 1)
plt.plot(time, signal)
plt.title('Time Domain Signal')
plt.xlabel('Time (s)')
plt.ylabel('Amplitude')

# Frequency domain
plt.subplot(2, 1, 2)
plt.plot(frequencies[:len(frequencies)//2], magnitude_spectrum[:len(magnitude_spectrum)//2])
plt.title('Frequency Domain Spectrum')
plt.xlabel('Frequency (Hz)')
plt.ylabel('Magnitude')
plt.tight_layout()
plt.show()
