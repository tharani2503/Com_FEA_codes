def triagen(p1,p2,p3):
    while True:
        import random
        alpha=random.random()
        beta=(1-alpha)*random.random()
        gamma=1-alpha-beta
        yield [alpha*p1[0]+beta*p2[0]+gamma*p3[0],
               alpha*p1[1]+beta*p2[1]+gamma*p3[1],
               alpha*p1[2]+beta*p2[2]+gamma*p3[2]]
tria1=triagen([0,0,0],[1,0,0],[0,1,0])
tria2=triagen([0,0,0],[-1,0,0],[0,-1,0])

listofpts=[]
        
for i in range(100):
    listofpts.append(next(tria1))
    listofpts.append(next(tria2))

with open ("E:/ses10.csv",'w')as f:
    for i in listofpts:
        f.write(str(i[0])+','+str(i[1])+','+str(i[2])+'\n')
