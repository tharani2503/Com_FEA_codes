Python 3.12.3 (tags/v3.12.3:f6650f9, Apr  9 2024, 14:05:25) [MSC v.1938 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> def openhmmodel()
SyntaxError: expected ':'
>>> def openhmmodel():
...     import time
...     start= time.time()
...     import hm
...     model = hm.model()
...     file=model.readfile("C:\\Users\\vinothd\\optimization for Ashok Leyland\\ENFDIS_for morphing.hm",0)
...     end=time.time()
