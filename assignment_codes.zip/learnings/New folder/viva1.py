def timekeeper(pointer):
     def open(*args,**kwds):
         import time
         start=time.time()
         i=pointer(*args,**kwds)
         end=time.time()
         return end-start
 
 def logwrite(pointer):
     def open(*args,**kwds):
         print ("import started")
 
         i=pointer(*args,**kwds)
 
         print("import completed")
 
@timekeeper
@logwrite
def openhmmodel(i):
     import time
     start= time.time()
     import hm
     model = hm.Model()
     file=model.readfile("C:\\Users\\vinothd\\optimization for Ashok Leyland\\ENFDIS_for morphing.hm",0)
     end=time.time()
     print(end-start)
     return end-start

