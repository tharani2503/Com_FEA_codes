####def something(a,b,c):
####    print(a,b,c)
##def mydecorator(fp):
##    def innerfunc(*args,**kwds):
####        timer  code
##        i=fp(*args,**kwds)
####        timer end
##        print(525)
##        return(i)
##    return(innerfunc)
##@mydecorator
##def anotherfunc():
##    print(343)
##    
##@mydecorator
##def timefunc():
##    pass\
import time
##begin=time.time()
##for i in range(10):
##    print("tony")
##time.sleep(1)
##end=time.time()
##t=begin-end
##print(t)
##def decorator (fp):
##    def wrap(*args,**kwds):
##        import time
##        start=time.time()
##        print(" in")
##
##        i=fp(*args,**kwds)
##        time.sleep(1)
##        end= time.time()
##        print(" out")
##
##        print("computation time is = ",end-start)
##        return i
##    return wrap
##
####@decorator
##def carea(*args):
##    area=[3.11*radius**2 for radius in args]
##    print(area)
def function (a=[]):
    for i in a:
        print('strating for loop')
        yield i
        print('continuing loop')
##        return i
##a=[]
##fibo=[]
##def fibonacci(first,second):
##    for i in range(0,10):
####        while len(fibo)<102:
##          yield first+second
##          temp=first+second
##          a.append(temp)
##          first=second
##          second=temp
##          if len(a)==10:
##              print(a)

rangerlist=[]
def ranger(*args):
    if len(args)==1:
        end=args[0]
        a=0
        for i in range(0,end):
            temp=i
##            a=temp+1
            rangerlist.append(temp)
            
            if len(rangerlist)==end:
                print(rangerlist)
####     assignment 4#  #
def ranger(*args):
    if len(args)==1:
        if bool(len(args)==1 and args[0]>0):
            i=0
            end=args[0]
            a=[]
            while len(a)<end:
                yield i
                temp=i
##                a.append(temp)
                i=temp+1
                
        else:
            print('wrong input')
            print('1. if input is single number it should be a "positive integer"')
            
        
    if len(args)==2:
        if bool(len(args)==2 and args[1]>args[0]):
         start=args[0]
         end=args[1]
         a=[start]
##          print(end-start)
         b=abs(end-start)
         while len(a)< b:
             yield start+1
             temp=start+1
             start=temp
##             a.append(temp)
##             if len(a)== b:
##                 print(a)
        else:
            print('wrong input')
            print('if inputs are two numbers it should be in the format of args[1]> args[0]')
            

    if len(args)==3:
        if bool(args[1]>args[0] and args[2]>0):
            start=args[0]
            end=args[1]
            stepsize=args[2]
            a=[start]
            b=abs((start-end)/stepsize)
            while len(a)<b:
                temp=start+stepsize
                start=temp
                a.append(temp)
                if len(a)==b:
                    print(a)
        elif bool(args[1]<args[0] and args[2]<0):
            start=args[0]
            end=args[1]
            stepsize=args[2]
            a=[start]
            b=abs(int((start-end)/stepsize))
            while len(a)<b:
                temp=start+stepsize
                start=temp
                a.append(temp)
                if len(a)==b:
                    print(a)
        else:
                 print('wrong input')
                 print('if inputs are 3 numbers  the format should satisfy either of two conditions')
                 print('condition1: args[1]<arg[0] and args[2]<0')
                 print('condition2: args[1]>args[0] and args[2]>0')
        
        

            
            
