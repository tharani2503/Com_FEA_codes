import numpy as np
import matplotlib.pyplot as plt
time=[]
disp=[]
print("enter input in mass,stiffness,initial displacement,initial velocity,time")
def undampedfree(*args):
    m,k,inidisp,inivel,t=args
    omegan=(k/m)**0.5
    for i in range(0,t,1):
         j = i/1000
         time.append(i)
         d= ((inidisp)*(np.cos(omegan*j)))+((inivel/omegan)*(np.sin(omegan*j)))
         disp.append(d)
    print(int((omegan)/(2*(np.pi))))    
    


    plt.plot([time],[disp],'ro')
    plt.show()
    

undampedfree(1,100,2,0,2000)  


##def dampedfree(*args):
##
##
##    T=np.arange(0,time,0.001)
##    D=
    

