##y=2*(a*x)**0.5
import matplotlib.pyplot as plt
import numpy as np

##inputs

x=[]
Y=[]
a=1
points=[]

##
for i in range(101):
    x.append(i)

for i in x:
    y=2*(a*i)**0.5
    Y.append(y)

    
##plotting   
    
plt.plot(x,Y,'bo')
plt.show()
print(Y)
print(x)


for i in range (101):
    points.append((x[i],Y[i],0))

print(points)
